﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class LookForPlayer : MonoBehaviour
{
    public GameObject player;
    public GameObject patroller;
    public bool canSeePlayer;
    public float fov = 60;
    public float playerDistance = 20;
    RaycastHit hit;
    Color defColor;

    private void Start()
    {
        defColor = gameObject.transform.parent.GetComponent<Renderer>().material.color;
    }
    // Update is called once per frame
    void Update()
    {
        // Need code for obstacles
        // Test for player distance (if not close, don't set true) (Double the distance)
        // Gun for killing AI
        // Destroy navmesh agent and patrol agent
        // add rigidbody, so that "ragdoll" happens.

        Vector3 rayDirection = player.transform.position - transform.position;
        float angle = Vector3.Angle(rayDirection, transform.forward);

        if(angle < fov)
        {
            if (Physics.Raycast(transform.position, rayDirection, out hit, playerDistance))
            {
                Debug.Log("I am looking at " + hit.collider.name);
                if (hit.collider.CompareTag("Player"))
                {
                    if ((player.transform.position - transform.position).magnitude >= playerDistance / 2)
                    {
                        canSeePlayer = true;
                    }
                }
                else
                {
                    canSeePlayer = false;
                }
            }
        }

        if (canSeePlayer)
        {
            patroller.GetComponent<Patrol>().agent.destination = player.transform.position;
            gameObject.transform.parent.GetComponent<Renderer>().material.color = Color.red;
        }
        else
        {
            gameObject.transform.parent.GetComponent<Renderer>().material.color = defColor;
        }

        Debug.DrawRay(transform.position, transform.forward * 5);
        Debug.DrawRay(transform.position, rayDirection, canSeePlayer ? Color.green : Color.red);
    }
}
