﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class LookForPlayer : MonoBehaviour
{
    public Transform player;
    public bool canSeePlayer;
    public float fov = 60;

    // Update is called once per frame
    void Update()
    {
        Vector3 rayDirection = player.position - transform.position;
        float angle = Vector3.Angle(rayDirection, transform.forward);

        if(angle < fov)
        {
            // Need code for obstacles
            // Test for player distance (if not close, don't set true) (Double the distance)
            // Gun for killing AI
                // Destroy navmesh agent and patrol agent
                // add rigidbody, so that "ragdoll" happens.
            canSeePlayer = true;
        }

        // Allow player too spawn turret that can shoot enemies to kill them!



        Debug.DrawRay(transform.position, transform.forward * 5);
        Debug.DrawRay(transform.position, rayDirection, canSeePlayer ? Color.green : Color.red);
        Debug.Log("Angle to player: " + angle);
    }
}
