﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.AI;

public class Spawner : MonoBehaviour
{
    public MoveTo AIPrefab;
    public Transform goal;
    public float interval = 2;
    // Start is called before the first frame update
    void Start()
    {
        StartCoroutine(SpawnAI());
    }

    IEnumerator SpawnAI()
    {
        while(true)
        {
            yield return new WaitForSeconds(interval);
            MoveTo copy = Instantiate(AIPrefab, transform.position, transform.rotation);

            copy.goal = goal;
        }
    }
}
